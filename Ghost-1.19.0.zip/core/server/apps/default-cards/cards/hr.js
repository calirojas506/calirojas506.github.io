module.exports = {
    name: 'card-hr',
    type: 'dom',
    render(opts) {
        return opts.env.dom.createElement('hr');
    }
};
